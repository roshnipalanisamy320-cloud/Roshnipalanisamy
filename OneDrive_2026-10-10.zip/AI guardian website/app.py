from flask import Flask, render_template, jsonify
from datetime import datetime
from threading import Lock

app = Flask(__name__)

lock = Lock()

dashboard = {
    "heart_rate": 75,
    "motion": "Normal Activity",
    "acceleration": 1.0,
    "battery": 85,
    "location": "Kannampalayam \n Coimbatore",
    "status": "Normal Activity",
    "alerts": []
}


def get_time():
    return datetime.now().strftime("%d-%m-%Y %I:%M:%S %p")


@app.route("/")
def home():
    with lock:
        data = {
            **dashboard,
            "alerts": list(dashboard["alerts"])
        }

    return render_template("index.html", data=data)


@app.route("/data")
def get_data():
    with lock:
        return jsonify({
            **dashboard,
            "alerts": list(dashboard["alerts"])
        })


@app.route("/simulate/<action>", methods=["POST"])
def simulate(action):

    with lock:

        if action == "normal":

            dashboard["heart_rate"] = 75
            dashboard["motion"] = "Normal Activity"
            dashboard["acceleration"] = 1.0
            dashboard["battery"] = 85
            dashboard["status"] = "Normal Activity"

        elif action == "fall":

            dashboard["heart_rate"] = 110
            dashboard["motion"] = "Possible Fall Detected"
            dashboard["acceleration"] = 3.5
            dashboard["status"] = "Fall Alert"

            dashboard["alerts"].insert(0, {
                "time": get_time(),
                "event": "Possible Fall Detected",
                "status": "Warning"
            })

        elif action == "emergency":

            dashboard["heart_rate"] = 125
            dashboard["motion"] = "Abnormal Movement"
            dashboard["acceleration"] = 4.5
            dashboard["status"] = "Emergency"

            dashboard["alerts"].insert(0, {
                "time": get_time(),
                "event": "Emergency Triggered",
                "status": "Critical"
            })

        elif action == "reset":

            dashboard["heart_rate"] = 75
            dashboard["motion"] = "Normal Activity"
            dashboard["acceleration"] = 1.0
            dashboard["battery"] = 85
            dashboard["location"] = "Coimbatore, Tamil Nadu"
            dashboard["status"] = "Normal Activity"
            dashboard["alerts"].clear()

        else:
            return jsonify({
                "error": "Invalid action"
            }), 400

        dashboard["alerts"] = dashboard["alerts"][:10]

        result = {
            **dashboard,
            "alerts": list(dashboard["alerts"])
        }

    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)